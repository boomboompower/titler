chrome.browserAction.onClicked.addListener(function(tab) {
	var message = confirm("Select your archive type: \n\nOk to use webarchive\nCancel to use archive.is");
	var string = "https://google.com/";
	if (message == true) {
		string = 'https://web.archive.org/save/';
	} else {
		string = 'https://archive.today/?run=1&url=';
	}
	// var action_url = "javascript:window.print();";
	chrome.tabs.update(tab.id, {url: action_url});
	open(string + (message ? window.location : encodeURIComponent(window.location)));
});
