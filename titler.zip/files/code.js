document.addEventListener('DOMContentLoaded', function () {
	document.getElementById('changeTitle').addEventListener('click', buttonClick);
	document.getElementById('newTitle').addEventListener('keypress', handleKeyPress);
});

function buttonClick() {
    chrome.tabs.executeScript(null, {
        code: "var head = document.createElement('head');var title = document.createElement('title');var text = document.createTextNode('" + document.getElementById("newTitle").value + "');title.appendChild(text);head.appendChild(title);document.body.appendChild(head);document.title='" + document.getElementById("newTitle").value + "';"
    });
    window.close();
}

function handleKeyPress(e) {
    var key = e.keyCode || e.which;
    if (key == 13) {
        buttonClick();
    }
}