var newTitle = "";
var head = document.createElement('head');
var title = document.createElement('title');
var text = document.createTextNode(newTitle);
title.appendChild(text);
head.appendChild(title);
document.body.appendChild(head);

/*
if (newTitle != "" ) {
	newTitle = escapeInput(newTitle);
	var head = document.createElement('head');
	var title = document.createElement('title');
	var text = document.createTextNode(newTitle);
	title.appendChild(text);
	head.appendChild(title);
	document.body.appendChild(head);
}
*/